function KIBRA_BEHAVIOR_ANALYSIS_REMOVE_JUMPS(Filename)

%This load the data for Analyzed_Data_MAH01056_Times_3664_to_3759 and
%removes specific segments where the identified location of the mouse
%jumped significantly due to poor video processing.  It only removes a
%handful of points, but because the points jumped such a large distance, it
%caused the calculated velocity to be unrealistic.
load(Filename);
Time_Change=diff(Analyzed_Data(:,23));
Time_Change(end+1)=Time_Change(end);

Time_Change=Time_Change(Analyzed_Data(:,14)>10,:);
Analyzed_Data=Analyzed_Data(Analyzed_Data(:,14)>10,:);
Time_Change=Time_Change(Analyzed_Data(:,14)<686 | Analyzed_Data(:,14)>690 | Analyzed_Data(:,15)<115 | Analyzed_Data(:,15)>125,:);
Analyzed_Data=Analyzed_Data(Analyzed_Data(:,14)<686 | Analyzed_Data(:,14)>690 | Analyzed_Data(:,15)<115 | Analyzed_Data(:,15)>125,:);
Time_Change=Time_Change(Analyzed_Data(:,14)<698 | Analyzed_Data(:,14)>700 | Analyzed_Data(:,15)<225 | Analyzed_Data(:,15)>236,:);
Analyzed_Data=Analyzed_Data(Analyzed_Data(:,14)<698 | Analyzed_Data(:,14)>700 | Analyzed_Data(:,15)<225 | Analyzed_Data(:,15)>236,:);
Time_Change=Time_Change(Analyzed_Data(:,14)<859 | Analyzed_Data(:,14)>876 | Analyzed_Data(:,15)<570 | Analyzed_Data(:,15)>590,:);
Analyzed_Data=Analyzed_Data(Analyzed_Data(:,14)<859 | Analyzed_Data(:,14)>876 | Analyzed_Data(:,15)<570 | Analyzed_Data(:,15)>590,:);

X_Movement=diff(Analyzed_Data(:,14));
X_Movement(end+1)=X_Movement(end);
Y_Movement=diff(Analyzed_Data(:,15));
Y_Movement(end+1)=Y_Movement(end);
[FilterA,FilterB]=butter(2,0.2);
X_Movement=filtfilt(FilterA,FilterB,X_Movement);
Y_Movement=filtfilt(FilterA,FilterB,Y_Movement);
Analyzed_Data(:,24)=sqrt((X_Movement.^2)+(Y_Movement.^2));
Analyzed_Data(:,24)=Analyzed_Data(:,24)*(96/710);  %This puts the movement into cm (the arena is 96 cm diameter and 710 pixels in diameter)
Analyzed_Data(:,25)=abs(Analyzed_Data(:,24)./Time_Change);  
Analyzed_Data(Analyzed_Data(:,25)<0,25)=0;

%This repeats the analysis from the original program on the restricted dataset 
if sum(Analyzed_Data(:,28)==301)>0
    Latency_To_First_Goal_Entry=Analyzed_Data(find(Analyzed_Data(:,28)==301,1,'first'),23);
    Path_Length_To_First_Goal_Entry=sum(Analyzed_Data(1:find(Analyzed_Data(:,28)==301,1,'first'),24));
else  %If the rat never finds the goal
    Latency_To_First_Goal_Entry=max(Analyzed_Data(:,23));
    Path_Length_To_First_Goal_Entry=sum(Analyzed_Data(:,24));
end
for N=1:size(Occupancy_Per_Area)
    Occupancy_Per_Area(N,2)=sum(Analyzed_Data(:,28)==Occupancy_Per_Area(N,1))*mean(Time_Change);
    Occupancy_Per_Area(N,3)=sum(Analyzed_Data(Analyzed_Data(:,28)==Occupancy_Per_Area(N,1),24));
    Occupancy_Per_Area_First_30_Seconds(N,2)=sum(Analyzed_Data(:,23)<=30 & Analyzed_Data(:,28)==Occupancy_Per_Area(N,1))*mean(Time_Change);
    Occupancy_Per_Area_First_30_Seconds(N,3)=sum(Analyzed_Data(Analyzed_Data(:,23)<=30 & Analyzed_Data(:,28)==Occupancy_Per_Area(N,1),24));
end
Total_Distance_Traveled=sum(Analyzed_Data(:,24));
Total_Occupancy=max(Analyzed_Data(:,23));
Mean_Overall_Velocity=mean(Analyzed_Data(:,25));
Mean_Velocity_When_Moving=mean(Analyzed_Data(Analyzed_Data(:,25)>=3,25));
Total_Distance_Traveled_First_30_Seconds=sum(Analyzed_Data(Analyzed_Data(:,23)<=30,24));
Total_Occupancy_First_30_Seconds=max(Analyzed_Data(Analyzed_Data(:,23)<=30,23));
Mean_Overall_Velocity_First_30_Seconds=mean(Analyzed_Data(Analyzed_Data(:,23)<=30,25));
Mean_Velocity_When_Moving_First_30_Seconds=mean(Analyzed_Data(Analyzed_Data(:,23)<=30 & Analyzed_Data(:,25)>=3,25));

%This saves the new data
eval(sprintf('save(''%s_NoJumps'',''Analyzed_Data'',''Occupancy_Per_Area'',''Latency_To_First_Goal_Entry'',''Path_Length_To_First_Goal_Entry'',''Total_Distance_Traveled'',''Total_Occupancy'',''Mean_Overall_Velocity'',''Mean_Velocity_When_Moving'');',Filename));
warning('off','all')
eval(sprintf('Filename=''%s_NoJumps.xlsx'';',Filename));
Combined_Data={'Latency to first goal entry',Latency_To_First_Goal_Entry;'Path Length to first goal entry',Path_Length_To_First_Goal_Entry;'Total distance traveled',Total_Distance_Traveled;'Total occupancy time',Total_Occupancy;'Mean Velocity',Mean_Overall_Velocity;'Mean Velocity when moving (>3 cm/s)',Mean_Velocity_When_Moving};
xlswrite(Filename,Combined_Data,'EntireExperiment','A1');
Combined_Occupancy_Data={'Region','Duration (s)','Path Length (cm)';Occupancy_Per_Area(1,1),Occupancy_Per_Area(1,2),Occupancy_Per_Area(1,3);Occupancy_Per_Area(2,1),Occupancy_Per_Area(2,2),Occupancy_Per_Area(2,3);Occupancy_Per_Area(3,1),Occupancy_Per_Area(3,2),Occupancy_Per_Area(3,3);Occupancy_Per_Area(4,1),Occupancy_Per_Area(4,2),Occupancy_Per_Area(4,3);Occupancy_Per_Area(5,1),Occupancy_Per_Area(5,2),Occupancy_Per_Area(5,3);Occupancy_Per_Area(6,1),Occupancy_Per_Area(6,2),Occupancy_Per_Area(6,3);Occupancy_Per_Area(7,1),Occupancy_Per_Area(7,2),Occupancy_Per_Area(7,3);Occupancy_Per_Area(8,1),Occupancy_Per_Area(8,2),Occupancy_Per_Area(8,3);Occupancy_Per_Area(9,1),Occupancy_Per_Area(9,2),Occupancy_Per_Area(9,3);Occupancy_Per_Area(10,1),Occupancy_Per_Area(10,2),Occupancy_Per_Area(10,3);Occupancy_Per_Area(11,1),Occupancy_Per_Area(11,2),Occupancy_Per_Area(11,3);Occupancy_Per_Area(12,1),Occupancy_Per_Area(12,2),Occupancy_Per_Area(12,3);Occupancy_Per_Area(13,1),Occupancy_Per_Area(13,2),Occupancy_Per_Area(13,3);Occupancy_Per_Area(14,1),Occupancy_Per_Area(14,2),Occupancy_Per_Area(14,3);Occupancy_Per_Area(15,1),Occupancy_Per_Area(15,2),Occupancy_Per_Area(15,3);Occupancy_Per_Area(16,1),Occupancy_Per_Area(16,2),Occupancy_Per_Area(16,3);Occupancy_Per_Area(17,1),Occupancy_Per_Area(17,2),Occupancy_Per_Area(17,3);Occupancy_Per_Area(18,1),Occupancy_Per_Area(18,2),Occupancy_Per_Area(18,3);Occupancy_Per_Area(19,1),Occupancy_Per_Area(19,2),Occupancy_Per_Area(19,3);Occupancy_Per_Area(20,1),Occupancy_Per_Area(20,2),Occupancy_Per_Area(20,3);Occupancy_Per_Area(21,1),Occupancy_Per_Area(21,2),Occupancy_Per_Area(21,3);Occupancy_Per_Area(22,1),Occupancy_Per_Area(22,2),Occupancy_Per_Area(22,3);Occupancy_Per_Area(23,1),Occupancy_Per_Area(23,2),Occupancy_Per_Area(23,3);Occupancy_Per_Area(24,1),Occupancy_Per_Area(24,2),Occupancy_Per_Area(24,3);Occupancy_Per_Area(25,1),Occupancy_Per_Area(25,2),Occupancy_Per_Area(25,3);Occupancy_Per_Area(26,1),Occupancy_Per_Area(26,2),Occupancy_Per_Area(26,3);Occupancy_Per_Area(27,1),Occupancy_Per_Area(27,2),Occupancy_Per_Area(27,3);Occupancy_Per_Area(28,1),Occupancy_Per_Area(28,2),Occupancy_Per_Area(28,3);Occupancy_Per_Area(29,1),Occupancy_Per_Area(29,2),Occupancy_Per_Area(29,3);Occupancy_Per_Area(30,1),Occupancy_Per_Area(30,2),Occupancy_Per_Area(30,3);Occupancy_Per_Area(31,1),Occupancy_Per_Area(31,2),Occupancy_Per_Area(31,3);Occupancy_Per_Area(32,1),Occupancy_Per_Area(32,2),Occupancy_Per_Area(32,3);Occupancy_Per_Area(33,1),Occupancy_Per_Area(33,2),Occupancy_Per_Area(33,3)};
xlswrite(Filename,Combined_Occupancy_Data,'EntireExperiment','E1');
xlswrite(Filename,{'Total Duration In Center','Total Path Length In Center','Total Duration In 200s','Total Path Length In 200s','Total Duration in 300s','Total Path Length in 300s';sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)<200,2)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)<200,3)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>200 & Occupancy_Per_Area(:,1)<300,2)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>200 & Occupancy_Per_Area(:,1)<300,3)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>300,2)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>300,3))},'EntireExperiment','I1');
Combined_Data_First_30_Seconds={'Latency to first goal entry',Latency_To_First_Goal_Entry;'Path Length to first goal entry',Path_Length_To_First_Goal_Entry;'Total distance traveled',Total_Distance_Traveled_First_30_Seconds;'Total occupancy time',Total_Occupancy_First_30_Seconds;'Mean Velocity',Mean_Overall_Velocity_First_30_Seconds;'Mean Velocity when moving (>3 cm/s)',Mean_Velocity_When_Moving_First_30_Seconds};
xlswrite(Filename,Combined_Data_First_30_Seconds,'First30Seconds','A1');
Combined_Occupancy_Data_First_30_Seconds={'Region','Duration (s)','Path Length (cm)';Occupancy_Per_Area_First_30_Seconds(1,1),Occupancy_Per_Area_First_30_Seconds(1,2),Occupancy_Per_Area_First_30_Seconds(1,3);Occupancy_Per_Area_First_30_Seconds(2,1),Occupancy_Per_Area_First_30_Seconds(2,2),Occupancy_Per_Area_First_30_Seconds(2,3);Occupancy_Per_Area_First_30_Seconds(3,1),Occupancy_Per_Area_First_30_Seconds(3,2),Occupancy_Per_Area_First_30_Seconds(3,3);Occupancy_Per_Area_First_30_Seconds(4,1),Occupancy_Per_Area_First_30_Seconds(4,2),Occupancy_Per_Area_First_30_Seconds(4,3);Occupancy_Per_Area_First_30_Seconds(5,1),Occupancy_Per_Area_First_30_Seconds(5,2),Occupancy_Per_Area_First_30_Seconds(5,3);Occupancy_Per_Area_First_30_Seconds(6,1),Occupancy_Per_Area_First_30_Seconds(6,2),Occupancy_Per_Area_First_30_Seconds(6,3);Occupancy_Per_Area_First_30_Seconds(7,1),Occupancy_Per_Area_First_30_Seconds(7,2),Occupancy_Per_Area_First_30_Seconds(7,3);Occupancy_Per_Area_First_30_Seconds(8,1),Occupancy_Per_Area_First_30_Seconds(8,2),Occupancy_Per_Area_First_30_Seconds(8,3);Occupancy_Per_Area_First_30_Seconds(9,1),Occupancy_Per_Area_First_30_Seconds(9,2),Occupancy_Per_Area_First_30_Seconds(9,3);Occupancy_Per_Area_First_30_Seconds(10,1),Occupancy_Per_Area_First_30_Seconds(10,2),Occupancy_Per_Area_First_30_Seconds(10,3);Occupancy_Per_Area_First_30_Seconds(11,1),Occupancy_Per_Area_First_30_Seconds(11,2),Occupancy_Per_Area_First_30_Seconds(11,3);Occupancy_Per_Area_First_30_Seconds(12,1),Occupancy_Per_Area_First_30_Seconds(12,2),Occupancy_Per_Area_First_30_Seconds(12,3);Occupancy_Per_Area_First_30_Seconds(13,1),Occupancy_Per_Area_First_30_Seconds(13,2),Occupancy_Per_Area_First_30_Seconds(13,3);Occupancy_Per_Area_First_30_Seconds(14,1),Occupancy_Per_Area_First_30_Seconds(14,2),Occupancy_Per_Area_First_30_Seconds(14,3);Occupancy_Per_Area_First_30_Seconds(15,1),Occupancy_Per_Area_First_30_Seconds(15,2),Occupancy_Per_Area_First_30_Seconds(15,3);Occupancy_Per_Area_First_30_Seconds(16,1),Occupancy_Per_Area_First_30_Seconds(16,2),Occupancy_Per_Area_First_30_Seconds(16,3);Occupancy_Per_Area_First_30_Seconds(17,1),Occupancy_Per_Area_First_30_Seconds(17,2),Occupancy_Per_Area_First_30_Seconds(17,3);Occupancy_Per_Area_First_30_Seconds(18,1),Occupancy_Per_Area_First_30_Seconds(18,2),Occupancy_Per_Area_First_30_Seconds(18,3);Occupancy_Per_Area_First_30_Seconds(19,1),Occupancy_Per_Area_First_30_Seconds(19,2),Occupancy_Per_Area_First_30_Seconds(19,3);Occupancy_Per_Area_First_30_Seconds(20,1),Occupancy_Per_Area_First_30_Seconds(20,2),Occupancy_Per_Area_First_30_Seconds(20,3);Occupancy_Per_Area_First_30_Seconds(21,1),Occupancy_Per_Area_First_30_Seconds(21,2),Occupancy_Per_Area_First_30_Seconds(21,3);Occupancy_Per_Area_First_30_Seconds(22,1),Occupancy_Per_Area_First_30_Seconds(22,2),Occupancy_Per_Area_First_30_Seconds(22,3);Occupancy_Per_Area_First_30_Seconds(23,1),Occupancy_Per_Area_First_30_Seconds(23,2),Occupancy_Per_Area_First_30_Seconds(23,3);Occupancy_Per_Area_First_30_Seconds(24,1),Occupancy_Per_Area_First_30_Seconds(24,2),Occupancy_Per_Area_First_30_Seconds(24,3);Occupancy_Per_Area_First_30_Seconds(25,1),Occupancy_Per_Area_First_30_Seconds(25,2),Occupancy_Per_Area_First_30_Seconds(25,3);Occupancy_Per_Area_First_30_Seconds(26,1),Occupancy_Per_Area_First_30_Seconds(26,2),Occupancy_Per_Area_First_30_Seconds(26,3);Occupancy_Per_Area_First_30_Seconds(27,1),Occupancy_Per_Area_First_30_Seconds(27,2),Occupancy_Per_Area_First_30_Seconds(27,3);Occupancy_Per_Area_First_30_Seconds(28,1),Occupancy_Per_Area_First_30_Seconds(28,2),Occupancy_Per_Area_First_30_Seconds(28,3);Occupancy_Per_Area_First_30_Seconds(29,1),Occupancy_Per_Area_First_30_Seconds(29,2),Occupancy_Per_Area_First_30_Seconds(29,3);Occupancy_Per_Area_First_30_Seconds(30,1),Occupancy_Per_Area_First_30_Seconds(30,2),Occupancy_Per_Area_First_30_Seconds(30,3);Occupancy_Per_Area_First_30_Seconds(31,1),Occupancy_Per_Area_First_30_Seconds(31,2),Occupancy_Per_Area_First_30_Seconds(31,3);Occupancy_Per_Area_First_30_Seconds(32,1),Occupancy_Per_Area_First_30_Seconds(32,2),Occupancy_Per_Area_First_30_Seconds(32,3);Occupancy_Per_Area_First_30_Seconds(33,1),Occupancy_Per_Area_First_30_Seconds(33,2),Occupancy_Per_Area_First_30_Seconds(33,3)};
xlswrite(Filename,Combined_Occupancy_Data_First_30_Seconds,'First30Seconds','E1');
xlswrite(Filename,{'Total Duration In Center','Total Path Length In Center','Total Duration In 200s','Total Path Length In 200s','Total Duration in 300s','Total Path Length in 300s';sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)<200,2)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)<200,3)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>200 & Occupancy_Per_Area_First_30_Seconds(:,1)<300,2)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>200 & Occupancy_Per_Area_First_30_Seconds(:,1)<300,3)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>300,2)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>300,3))},'First30Seconds','I1');
xlswrite(Filename,Analyzed_Data,'RawData','A1');
warning('on','all')


end