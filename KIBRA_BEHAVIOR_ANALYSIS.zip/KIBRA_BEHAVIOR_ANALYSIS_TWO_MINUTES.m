function KIBRA_BEHAVIOR_ANALYSIS_TWO_MINUTES(Movie_Name,DeepLabCut_Data,Start_Time)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% The purpose of this program is to pull up the raw video file for KIBRA
% Barnes maze experiments along with the pre-processed DeepLabCut position
% data for each video frame and perform several analyses on the data.
% 
% Movie_Name is the name of the file of the raw movie data.  This program
% assumes the video is a mp4 format.  DeepLabCut_Data is the name of the
% file of the DeepLabCut pre-processed data.  The program makes several
% assumptions about the format of that data.  Start_Time and End_Time are
% the start and end points in the video (in seconds from the start) to
% analyze. 
% 
% You run this program by typing in
% KIBRA_BEHAVIOR_ANALYSIS(Movie_Name,DeepLabCut_Data,Start_Time,End_Time)
% and then hitting Enter.  Replace Movie_Name with the actual filename of
% hte movie in single quotes (i.e., 'MAH01023.mp4'), replace
% DeepLabCut_Data with the actual filename of the DeepLabCut data (i.e.,
% 'MAH01023DLC_resnet50_KibraConBarnesMazeMar2shuffle1_420000.csv'), and
% replace Start_Time and End_Time with the numerical values that you want
% to start and end analysis at (in seconds).  So, to analyze MAH01023.mp4
% from 77 seconds to 180 seconds into the movie using the data in
% MAH01023DLC_resnet50_KibraConBarnesMazeMar2shuffle1_420000.csv, you would
% enter:
% 
% KIBRA_BEHAVIOR_ANALYSIS_TWO_MINUTES('MAH01023.mp4','MAH01023DLC_resnet50_KibraConBarnesMazeMar2shuffle1_420000.csv',77,180);
% 
% It will then load up a single screenshot of the middle of those
% timepoints.  You will click on the "Center Select" button, then click on
% the center of the maze.  It will draw a small circle where you clicked.
% You can repeat this part until you are happy with where you clicked.
% 
% Then you will click on the "Wall Select" button.  You will click the
% corner of each wall (the inner, clockwise corner), starting with the wall
% of the Goal region and then clicking on each wall (the inner, clockwise
% corner), moving in the counter-clockwise direction.
% 
% After all 11 clicks, it will draw out the analysis boundaries.  If you
% are unhappy, you can repeat this last step.
% 
% Once you are happy with the boundaries, click the "Analyze Data" button
% to process the data.  Then click the "Save and Close" button to save the
% data and close the graph.
% 
% The arena is split into several segments, each with a three-digit
% numerical code. The hundreds place is how far from the center, and the
% tens/ones place is which area you are in (01 is the Goal area).
% 
% Segment 101 is in the center, but in the pie slice that contains the Goal
% area
% Segment 202 is the outer area just inside of the walls in the pie slice
% adjacent to the Goal area.
% Segment 311 is the outer area just outside of the wall in the pie slice
% adjacent to the Goal area (but opposite area 02). 
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% First, the program needs to identify the physical structure of the arena.
% It does this by pulling up a frame between Start_Time and End_Time and
% allows the user to define the center of the arena and the lower edge of
% the goal wall.  From these two points, the program can calculate all of
% the cubby locations for future quantification.

warning('off','all')
End_Time=Start_Time+120;
Video=VideoReader(Movie_Name);
Video.CurrentTime=mean([Start_Time,End_Time]);
Frame=readFrame(Video);
Analyzed_Data=readmatrix(DeepLabCut_Data);
Analyzed_Data(:,23:28)=0;
Analyzed_Data(:,23)=Analyzed_Data(:,1)*(1/Video.FrameRate);
Analyzed_Data=Analyzed_Data(Analyzed_Data(:,23)>=Start_Time & Analyzed_Data(:,23)<=End_Time,:);
Analyzed_Data(:,23)=Analyzed_Data(:,23)-min(Analyzed_Data(:,23));  %Resets the start of each session to zero
[FilterA,FilterB]=butter(2,0.02);
Time_Change=diff(Analyzed_Data(:,23));
Time_Change(end+1)=Time_Change(end);
X_Movement=diff(Analyzed_Data(:,14));
X_Movement(end+1)=X_Movement(end);
Y_Movement=diff(Analyzed_Data(:,15));
Y_Movement(end+1)=Y_Movement(end);
% This filter smooths out the position data -- because the front or rear
% LED sometimes gets obscured by the camera, this causes very transient
% "jumps" in the calculated position which are small, but very fast, and
% make it seem like the rat is jumping back and forth when it's actually
% just standing in place.  This filter setting doesn't eliminate actual
% movement, only these very rapid jumps.
[FilterA,FilterB]=butter(2,0.2);
X_Movement=filtfilt(FilterA,FilterB,X_Movement);
Y_Movement=filtfilt(FilterA,FilterB,Y_Movement);
Analyzed_Data(:,24)=sqrt((X_Movement.^2)+(Y_Movement.^2));
Analyzed_Data(:,24)=Analyzed_Data(:,24)*(96/710);  %This puts the movement into cm (the arena is 96 cm diameter and 710 pixels in diameter)
Analyzed_Data(:,25)=abs(Analyzed_Data(:,24)./Time_Change);  
Analyzed_Data(Analyzed_Data(:,25)<0,25)=0;

% Analyzed_Data
% |   1    |   2   |   3   |   4   |   5   |   6   |   7   |   8   |   9   |  10   |  11   |  12   |  13   |  14   |  15   |  16   |  17   |  18   |  19   |  20   |  21   |  22   |  23  |    24    |    25    |     26      |      27     |   28    ||
% | Frame  | Snout | Snout | Snout | L-Ear | L-Ear | L-Ear | R-Ear | R-Ear | R-Ear | Head  | Head  | Head  | Body  | Body  | Body  | Tail1 | Tail1 | Tail1 | Tail2 | Tail2 | Tail2 | Time | Movement | Velocity |  Distance   |    Angle    | Current ||
% | Number | X-Bin | Y-Bin | Prob. | X-Bin | Y-Bin | Prob. | X-Bin | Y-Bin | Prob. | X-Bin | Y-Bin | Prob. | X-Bin | Y-Bin | Prob. | X-Bin | Y-Bin | Prob. | X-Bin | Y-Bin | Prob. | (s)  |   (cm)   |  (cm/s)  | From Center | From Center |  Area   ||

Occupancy_Per_Area=zeros(33,3);
Occupancy_Per_Area(:,1)=[101;102;103;104;105;106;107;108;109;110;111;201;202;203;204;205;206;207;208;209;210;211;301;302;303;304;305;306;307;308;309;310;311];
Occupancy_Per_Area_First_30_Seconds=zeros(33,3);
Occupancy_Per_Area_First_30_Seconds(:,1)=[101;102;103;104;105;106;107;108;109;110;111;201;202;203;204;205;206;207;208;209;210;211;301;302;303;304;305;306;307;308;309;310;311];
% Occupancy_Per_Area/Occupancy_Per_Area_First_30_Seconds
% |     1     |         2        |          3          |
% | Area Code | Duration In Area | Path Length In Area | 

Latency_To_First_Goal_Entry=0;
Path_Length_To_First_Goal_Entry=0;
Total_Distance_Traveled=0;
Total_Occupancy=0;
Mean_Overall_Velocity=0;
Mean_Velocity_When_Moving=0;
Total_Distance_Traveled_First_30_Seconds=0;
Total_Occupancy_First_30_Seconds=0;
Mean_Overall_Velocity_First_30_Seconds=0;
Mean_Velocity_When_Moving_First_30_Seconds=0;
Filename='X.xlsx';

% This builds the user interface
Figure1=figure('KeyPressFcn',@GPHDFV_KEY_PRESS);
set(Figure1,'Position',[100,100,800,600]);
subplot('Position',[0 0 0.8 1]);
imagesc(Frame);
hold on;
u0=uicontrol;
set(u0,'Position',[670 540 100 25]);
set(u0,'Callback',@KBA_CENTER_SELECT);
set(u0,'String','Center Select','FontSize',10);
u3=uicontrol;
set(u3,'Position',[670 510 100 25]);
set(u3,'Callback',@KBA_WALL_SELECT);
set(u3,'String','Wall Select','FontSize',10);
u4=uicontrol;
set(u4,'Position',[670 480 100 25]);
set(u4,'Callback',@KBA_CLEAR);
set(u4,'String','Clear Bounds','FontSize',10);
u1=uicontrol;
set(u1,'Position',[670 450 100 25]);
set(u1,'Callback',@KBA_ANALYZE_DATA);
set(u1,'String','Analyze Data','FontSize',10);
u2=uicontrol;
set(u2,'Position',[670 420 100 25]);
set(u2,'Callback',@KBA_CLOSE_AND_SAVE);
set(u2,'String','Save and Close','FontSize',10);
Center_Location=[0,0];
Angles=zeros(11,1);
Outer_Distance=0;
Inner_Distance=0;
Wall_Locations=zeros(11,2);


    function KBA_CLEAR(src,event)
        cla(Figure1);
        imagesc(Frame);
        Center_Location=[0,0];
        Angles=zeros(11,1);
        Outer_Distance=0;
        Inner_Distance=0;
        Wall_Locations=zeros(11,2);
    end

    function KBA_CENTER_SELECT(src,event)
        [X_Click,Y_Click]=ginputc(1,'Color','c');
        X1=X_Click(1);
        Y1=Y_Click(1);
        Center_Location=[X1,Y1];
        cla(Figure1);
        imagesc(Frame);
        viscircles(Center_Location,5,'Color','c');
        if Outer_Distance>0
            viscircles(Center_Location,Outer_Distance,'Color','c');
            viscircles(Center_Location,Inner_Distance,'Color','c');
            for N=1:11
                X_Diff=Wall_Locations(N,1)-Center_Location(1);
                Y_Diff=Wall_Locations(N,2)-Center_Location(2);
                if Y_Diff==0 && X_Diff>0
                    Wall_Angle=270;
                elseif Y_Diff==0 && X_Diff<0
                    Wall_Angle=90;
                elseif X_Diff==0 && Y_Diff>0
                    Wall_Angle=180;
                elseif X_Diff==0 && Y_Diff<0
                    Wall_Angle=360;
                elseif X_Diff>0 && Y_Diff>0
                    Wall_Angle=180+atand(abs(X_Diff)/abs(Y_Diff));
                elseif X_Diff>0 && Y_Diff<0
                    Wall_Angle=270+abs(atand(abs(Y_Diff)/abs(X_Diff)));
                elseif X_Diff<0 && Y_Diff>0
                    Wall_Angle=90+abs(atand(abs(Y_Diff)/abs(X_Diff)));
                elseif X_Diff<0 && Y_Diff<0
                    Wall_Angle=atand(abs(X_Diff)/abs(Y_Diff));
                else
                    Wall_Angle=0;
                end
                Angles(N,1)=Wall_Angle;
            end
            Angles(:,2)=0;
            Angles(1:(end-1),2)=Angles(2:end,1);
            Angles(end,2)=Angles(1);
            for N=1:11
                Inner_Intersection=[Center_Location(1)-(Inner_Distance*sind(Angles(N,1))),Center_Location(2)-(Inner_Distance*cosd(Angles(N,1)))];
                Outer_Intersection=[Center_Location(1)-(Outer_Distance*sind(Angles(N,1))),Center_Location(2)-(Outer_Distance*cosd(Angles(N,1)))];
                plot([Inner_Intersection(1),Outer_Intersection(1)],[Inner_Intersection(2),Outer_Intersection(2)],'c')
            end
        end
    end
        
    function KBA_WALL_SELECT(src,event)
        [X_Click,Y_Click]=ginputc(11,'Color','c');
        X1=X_Click(1);
        X2=X_Click(2);
        X3=X_Click(3);
        X4=X_Click(4);
        X5=X_Click(5);
        X6=X_Click(6);
        X7=X_Click(7);
        X8=X_Click(8);
        X9=X_Click(9);
        X10=X_Click(10);
        X11=X_Click(11);
        Y1=Y_Click(1);
        Y2=Y_Click(2);
        Y3=Y_Click(3);
        Y4=Y_Click(4);
        Y5=Y_Click(5);
        Y6=Y_Click(6);
        Y7=Y_Click(7);
        Y8=Y_Click(8);
        Y9=Y_Click(9);
        Y10=Y_Click(10);
        Y11=Y_Click(11);
        Wall_Locations=[[X1;X2;X3;X4;X5;X6;X7;X8;X9;X10;X11],[Y1;Y2;Y3;Y4;Y5;Y6;Y7;Y8;Y9;Y10;Y11]];
        if Center_Location(1)==0
            Center_Location(1)=mean(Wall_Locations(:,1));
        end
        if Center_Location(2)==0
            Center_Location(2)=mean(Wall_Locations(:,2));
        end
        cla(Figure1);
        imagesc(Frame);
        viscircles(Center_Location,5,'Color','c');
        for N=1:11
            plot(Wall_Locations(N,1),Wall_Locations(N,2),'co')
        end
        Outer_Distance=sqrt(((abs(Center_Location(1)-Wall_Locations(1,1)))^2)+((abs(Center_Location(2)-Wall_Locations(1,2)))^2));
        Inner_Distance=Outer_Distance*(3/4);
        viscircles(Center_Location,Outer_Distance,'Color','c');
        viscircles(Center_Location,Inner_Distance,'Color','c');
        for N=1:11
            X_Diff=Wall_Locations(N,1)-Center_Location(1);
            Y_Diff=Wall_Locations(N,2)-Center_Location(2);
            if Y_Diff==0 && X_Diff>0
                Wall_Angle=270;
            elseif Y_Diff==0 && X_Diff<0
                Wall_Angle=90;
            elseif X_Diff==0 && Y_Diff>0
                Wall_Angle=180;
            elseif X_Diff==0 && Y_Diff<0
                Wall_Angle=360;
            elseif X_Diff>0 && Y_Diff>0
                Wall_Angle=180+atand(abs(X_Diff)/abs(Y_Diff));
            elseif X_Diff>0 && Y_Diff<0
                Wall_Angle=270+abs(atand(abs(Y_Diff)/abs(X_Diff)));
            elseif X_Diff<0 && Y_Diff>0
                Wall_Angle=90+abs(atand(abs(Y_Diff)/abs(X_Diff)));
            elseif X_Diff<0 && Y_Diff<0
                Wall_Angle=atand(abs(X_Diff)/abs(Y_Diff));
            else
                Wall_Angle=0;
            end
            Angles(N,1)=Wall_Angle;
        end
        Angles(:,2)=0;
        Angles(1:(end-1),2)=Angles(2:end,1);
        Angles(end,2)=Angles(1);
        for N=1:11
            Inner_Intersection=[Center_Location(1)-(Inner_Distance*sind(Angles(N,1))),Center_Location(2)-(Inner_Distance*cosd(Angles(N,1)))];
            Outer_Intersection=[Center_Location(1)-(Outer_Distance*sind(Angles(N,1))),Center_Location(2)-(Outer_Distance*cosd(Angles(N,1)))];
            plot([Inner_Intersection(1),Outer_Intersection(1)],[Inner_Intersection(2),Outer_Intersection(2)],'c')
        end
    end

    function KBA_ANALYZE_DATA(src,event)
        Analyzed_Data(:,26)=sqrt(((Analyzed_Data(:,14)-Center_Location(1)).^2)+((Analyzed_Data(:,15)-Center_Location(2)).^2));
        for N=1:size(Analyzed_Data,1)
            X_Diff=Analyzed_Data(N,14)-Center_Location(1);
            Y_Diff=Analyzed_Data(N,15)-Center_Location(2);
            if Y_Diff==0 && X_Diff>0
                Angle=270;
            elseif Y_Diff==0 && X_Diff<0
                Angle=90;
            elseif X_Diff==0 && Y_Diff>0
                Angle=180;
            elseif X_Diff==0 && Y_Diff<0
                Angle=360;
            elseif X_Diff>0 && Y_Diff>0
                Angle=180+atand(abs(X_Diff)/abs(Y_Diff));
            elseif X_Diff>0 && Y_Diff<0
                Angle=270+abs(atand(abs(Y_Diff)/abs(X_Diff)));
            elseif X_Diff<0 && Y_Diff>0
                Angle=90+abs(atand(abs(Y_Diff)/abs(X_Diff)));
            elseif X_Diff<0 && Y_Diff<0
                Angle=atand(abs(X_Diff)/abs(Y_Diff));
            else
                Angle=0;
            end
            Analyzed_Data(N,27)=Angle;
            if Analyzed_Data(N,26)<Inner_Distance
                Area_Code=100;
            elseif Analyzed_Data(N,26)<Outer_Distance
                Area_Code=200;
            else
                Area_Code=300;
            end
            if Angle>max(max(Angles)) || Angle<min(min(Angles))
                Segment=find(Angles(:,1)==max(Angles(:,1)),1,'first');
            else
                Segment=find(Angles(:,1)<=Angle & Angles(:,2)>=Angle,1,'first');
            end
            Area_Code=Area_Code+Segment;
            Analyzed_Data(N,28)=Area_Code;
            clear Angle;
            clear Area_Code;
            clear Segment;
            viscircles(Center_Location,5,'Color','r');
        end
        if sum(Analyzed_Data(:,28)==301)>0
            Latency_To_First_Goal_Entry=Analyzed_Data(find(Analyzed_Data(:,28)==301,1,'first'),23);
            Path_Length_To_First_Goal_Entry=sum(Analyzed_Data(1:find(Analyzed_Data(:,28)==301,1,'first'),24));
        else  %If the rat never finds the goal
            Latency_To_First_Goal_Entry=max(Analyzed_Data(:,23));
            Path_Length_To_First_Goal_Entry=sum(Analyzed_Data(:,24));
        end
        for N=1:size(Occupancy_Per_Area)
            Occupancy_Per_Area(N,2)=sum(Analyzed_Data(:,28)==Occupancy_Per_Area(N,1))*(1/Video.FrameRate);
            Occupancy_Per_Area(N,3)=sum(Analyzed_Data(Analyzed_Data(:,28)==Occupancy_Per_Area(N,1),24));
            Occupancy_Per_Area_First_30_Seconds(N,2)=sum(Analyzed_Data(:,23)<=30 & Analyzed_Data(:,28)==Occupancy_Per_Area(N,1))*(1/Video.FrameRate);
            Occupancy_Per_Area_First_30_Seconds(N,3)=sum(Analyzed_Data(Analyzed_Data(:,23)<=30 & Analyzed_Data(:,28)==Occupancy_Per_Area(N,1),24));
        end
        Total_Distance_Traveled=sum(Analyzed_Data(:,24));
        Total_Occupancy=max(Analyzed_Data(:,23));
        Mean_Overall_Velocity=mean(Analyzed_Data(:,25));
        Mean_Velocity_When_Moving=mean(Analyzed_Data(Analyzed_Data(:,25)>=3,25));
        Total_Distance_Traveled_First_30_Seconds=sum(Analyzed_Data(Analyzed_Data(:,23)<=30,24));
        Total_Occupancy_First_30_Seconds=max(Analyzed_Data(Analyzed_Data(:,23)<=30,23));
        Mean_Overall_Velocity_First_30_Seconds=mean(Analyzed_Data(Analyzed_Data(:,23)<=30,25));
        Mean_Velocity_When_Moving_First_30_Seconds=mean(Analyzed_Data(Analyzed_Data(:,23)<=30 & Analyzed_Data(:,25)>=3,25));
    end

    function KBA_CLOSE_AND_SAVE(src,event)
        eval(sprintf('save(''Analyzed_Data_%s_Times_%d_to_%d'',''Analyzed_Data'',''Occupancy_Per_Area'',''Latency_To_First_Goal_Entry'',''Path_Length_To_First_Goal_Entry'',''Total_Distance_Traveled'',''Total_Occupancy'',''Mean_Overall_Velocity'',''Mean_Velocity_When_Moving'');',Movie_Name(1:end-4),Start_Time,End_Time));
        eval(sprintf('Filename=''Analyzed_Data_%s_Times_%d_to_%d.xlsx'';',Movie_Name(1:end-4),Start_Time,End_Time));
        Combined_Data={'Latency to first goal entry',Latency_To_First_Goal_Entry;'Path Length to first goal entry',Path_Length_To_First_Goal_Entry;'Total distance traveled',Total_Distance_Traveled;'Total occupancy time',Total_Occupancy;'Mean Velocity',Mean_Overall_Velocity;'Mean Velocity when moving (>3 cm/s)',Mean_Velocity_When_Moving};
        xlswrite(Filename,Combined_Data,'EntireExperiment','A1');
        Combined_Occupancy_Data={'Region','Duration (s)','Path Length (cm)';Occupancy_Per_Area(1,1),Occupancy_Per_Area(1,2),Occupancy_Per_Area(1,3);Occupancy_Per_Area(2,1),Occupancy_Per_Area(2,2),Occupancy_Per_Area(2,3);Occupancy_Per_Area(3,1),Occupancy_Per_Area(3,2),Occupancy_Per_Area(3,3);Occupancy_Per_Area(4,1),Occupancy_Per_Area(4,2),Occupancy_Per_Area(4,3);Occupancy_Per_Area(5,1),Occupancy_Per_Area(5,2),Occupancy_Per_Area(5,3);Occupancy_Per_Area(6,1),Occupancy_Per_Area(6,2),Occupancy_Per_Area(6,3);Occupancy_Per_Area(7,1),Occupancy_Per_Area(7,2),Occupancy_Per_Area(7,3);Occupancy_Per_Area(8,1),Occupancy_Per_Area(8,2),Occupancy_Per_Area(8,3);Occupancy_Per_Area(9,1),Occupancy_Per_Area(9,2),Occupancy_Per_Area(9,3);Occupancy_Per_Area(10,1),Occupancy_Per_Area(10,2),Occupancy_Per_Area(10,3);Occupancy_Per_Area(11,1),Occupancy_Per_Area(11,2),Occupancy_Per_Area(11,3);Occupancy_Per_Area(12,1),Occupancy_Per_Area(12,2),Occupancy_Per_Area(12,3);Occupancy_Per_Area(13,1),Occupancy_Per_Area(13,2),Occupancy_Per_Area(13,3);Occupancy_Per_Area(14,1),Occupancy_Per_Area(14,2),Occupancy_Per_Area(14,3);Occupancy_Per_Area(15,1),Occupancy_Per_Area(15,2),Occupancy_Per_Area(15,3);Occupancy_Per_Area(16,1),Occupancy_Per_Area(16,2),Occupancy_Per_Area(16,3);Occupancy_Per_Area(17,1),Occupancy_Per_Area(17,2),Occupancy_Per_Area(17,3);Occupancy_Per_Area(18,1),Occupancy_Per_Area(18,2),Occupancy_Per_Area(18,3);Occupancy_Per_Area(19,1),Occupancy_Per_Area(19,2),Occupancy_Per_Area(19,3);Occupancy_Per_Area(20,1),Occupancy_Per_Area(20,2),Occupancy_Per_Area(20,3);Occupancy_Per_Area(21,1),Occupancy_Per_Area(21,2),Occupancy_Per_Area(21,3);Occupancy_Per_Area(22,1),Occupancy_Per_Area(22,2),Occupancy_Per_Area(22,3);Occupancy_Per_Area(23,1),Occupancy_Per_Area(23,2),Occupancy_Per_Area(23,3);Occupancy_Per_Area(24,1),Occupancy_Per_Area(24,2),Occupancy_Per_Area(24,3);Occupancy_Per_Area(25,1),Occupancy_Per_Area(25,2),Occupancy_Per_Area(25,3);Occupancy_Per_Area(26,1),Occupancy_Per_Area(26,2),Occupancy_Per_Area(26,3);Occupancy_Per_Area(27,1),Occupancy_Per_Area(27,2),Occupancy_Per_Area(27,3);Occupancy_Per_Area(28,1),Occupancy_Per_Area(28,2),Occupancy_Per_Area(28,3);Occupancy_Per_Area(29,1),Occupancy_Per_Area(29,2),Occupancy_Per_Area(29,3);Occupancy_Per_Area(30,1),Occupancy_Per_Area(30,2),Occupancy_Per_Area(30,3);Occupancy_Per_Area(31,1),Occupancy_Per_Area(31,2),Occupancy_Per_Area(31,3);Occupancy_Per_Area(32,1),Occupancy_Per_Area(32,2),Occupancy_Per_Area(32,3);Occupancy_Per_Area(33,1),Occupancy_Per_Area(33,2),Occupancy_Per_Area(33,3)};
        xlswrite(Filename,Combined_Occupancy_Data,'EntireExperiment','E1');
        xlswrite(Filename,{'Total Duration In Center','Total Path Length In Center','Total Duration In 200s','Total Path Length In 200s','Total Duration in 300s','Total Path Length in 300s';sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)<200,2)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)<200,3)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>200 & Occupancy_Per_Area(:,1)<300,2)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>200 & Occupancy_Per_Area(:,1)<300,3)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>300,2)),sum(Occupancy_Per_Area(Occupancy_Per_Area(:,1)>300,3))},'EntireExperiment','I1');
        Combined_Data_First_30_Seconds={'Latency to first goal entry',Latency_To_First_Goal_Entry;'Path Length to first goal entry',Path_Length_To_First_Goal_Entry;'Total distance traveled',Total_Distance_Traveled_First_30_Seconds;'Total occupancy time',Total_Occupancy_First_30_Seconds;'Mean Velocity',Mean_Overall_Velocity_First_30_Seconds;'Mean Velocity when moving (>3 cm/s)',Mean_Velocity_When_Moving_First_30_Seconds};
        xlswrite(Filename,Combined_Data_First_30_Seconds,'First30Seconds','A1');
        Combined_Occupancy_Data_First_30_Seconds={'Region','Duration (s)','Path Length (cm)';Occupancy_Per_Area_First_30_Seconds(1,1),Occupancy_Per_Area_First_30_Seconds(1,2),Occupancy_Per_Area_First_30_Seconds(1,3);Occupancy_Per_Area_First_30_Seconds(2,1),Occupancy_Per_Area_First_30_Seconds(2,2),Occupancy_Per_Area_First_30_Seconds(2,3);Occupancy_Per_Area_First_30_Seconds(3,1),Occupancy_Per_Area_First_30_Seconds(3,2),Occupancy_Per_Area_First_30_Seconds(3,3);Occupancy_Per_Area_First_30_Seconds(4,1),Occupancy_Per_Area_First_30_Seconds(4,2),Occupancy_Per_Area_First_30_Seconds(4,3);Occupancy_Per_Area_First_30_Seconds(5,1),Occupancy_Per_Area_First_30_Seconds(5,2),Occupancy_Per_Area_First_30_Seconds(5,3);Occupancy_Per_Area_First_30_Seconds(6,1),Occupancy_Per_Area_First_30_Seconds(6,2),Occupancy_Per_Area_First_30_Seconds(6,3);Occupancy_Per_Area_First_30_Seconds(7,1),Occupancy_Per_Area_First_30_Seconds(7,2),Occupancy_Per_Area_First_30_Seconds(7,3);Occupancy_Per_Area_First_30_Seconds(8,1),Occupancy_Per_Area_First_30_Seconds(8,2),Occupancy_Per_Area_First_30_Seconds(8,3);Occupancy_Per_Area_First_30_Seconds(9,1),Occupancy_Per_Area_First_30_Seconds(9,2),Occupancy_Per_Area_First_30_Seconds(9,3);Occupancy_Per_Area_First_30_Seconds(10,1),Occupancy_Per_Area_First_30_Seconds(10,2),Occupancy_Per_Area_First_30_Seconds(10,3);Occupancy_Per_Area_First_30_Seconds(11,1),Occupancy_Per_Area_First_30_Seconds(11,2),Occupancy_Per_Area_First_30_Seconds(11,3);Occupancy_Per_Area_First_30_Seconds(12,1),Occupancy_Per_Area_First_30_Seconds(12,2),Occupancy_Per_Area_First_30_Seconds(12,3);Occupancy_Per_Area_First_30_Seconds(13,1),Occupancy_Per_Area_First_30_Seconds(13,2),Occupancy_Per_Area_First_30_Seconds(13,3);Occupancy_Per_Area_First_30_Seconds(14,1),Occupancy_Per_Area_First_30_Seconds(14,2),Occupancy_Per_Area_First_30_Seconds(14,3);Occupancy_Per_Area_First_30_Seconds(15,1),Occupancy_Per_Area_First_30_Seconds(15,2),Occupancy_Per_Area_First_30_Seconds(15,3);Occupancy_Per_Area_First_30_Seconds(16,1),Occupancy_Per_Area_First_30_Seconds(16,2),Occupancy_Per_Area_First_30_Seconds(16,3);Occupancy_Per_Area_First_30_Seconds(17,1),Occupancy_Per_Area_First_30_Seconds(17,2),Occupancy_Per_Area_First_30_Seconds(17,3);Occupancy_Per_Area_First_30_Seconds(18,1),Occupancy_Per_Area_First_30_Seconds(18,2),Occupancy_Per_Area_First_30_Seconds(18,3);Occupancy_Per_Area_First_30_Seconds(19,1),Occupancy_Per_Area_First_30_Seconds(19,2),Occupancy_Per_Area_First_30_Seconds(19,3);Occupancy_Per_Area_First_30_Seconds(20,1),Occupancy_Per_Area_First_30_Seconds(20,2),Occupancy_Per_Area_First_30_Seconds(20,3);Occupancy_Per_Area_First_30_Seconds(21,1),Occupancy_Per_Area_First_30_Seconds(21,2),Occupancy_Per_Area_First_30_Seconds(21,3);Occupancy_Per_Area_First_30_Seconds(22,1),Occupancy_Per_Area_First_30_Seconds(22,2),Occupancy_Per_Area_First_30_Seconds(22,3);Occupancy_Per_Area_First_30_Seconds(23,1),Occupancy_Per_Area_First_30_Seconds(23,2),Occupancy_Per_Area_First_30_Seconds(23,3);Occupancy_Per_Area_First_30_Seconds(24,1),Occupancy_Per_Area_First_30_Seconds(24,2),Occupancy_Per_Area_First_30_Seconds(24,3);Occupancy_Per_Area_First_30_Seconds(25,1),Occupancy_Per_Area_First_30_Seconds(25,2),Occupancy_Per_Area_First_30_Seconds(25,3);Occupancy_Per_Area_First_30_Seconds(26,1),Occupancy_Per_Area_First_30_Seconds(26,2),Occupancy_Per_Area_First_30_Seconds(26,3);Occupancy_Per_Area_First_30_Seconds(27,1),Occupancy_Per_Area_First_30_Seconds(27,2),Occupancy_Per_Area_First_30_Seconds(27,3);Occupancy_Per_Area_First_30_Seconds(28,1),Occupancy_Per_Area_First_30_Seconds(28,2),Occupancy_Per_Area_First_30_Seconds(28,3);Occupancy_Per_Area_First_30_Seconds(29,1),Occupancy_Per_Area_First_30_Seconds(29,2),Occupancy_Per_Area_First_30_Seconds(29,3);Occupancy_Per_Area_First_30_Seconds(30,1),Occupancy_Per_Area_First_30_Seconds(30,2),Occupancy_Per_Area_First_30_Seconds(30,3);Occupancy_Per_Area_First_30_Seconds(31,1),Occupancy_Per_Area_First_30_Seconds(31,2),Occupancy_Per_Area_First_30_Seconds(31,3);Occupancy_Per_Area_First_30_Seconds(32,1),Occupancy_Per_Area_First_30_Seconds(32,2),Occupancy_Per_Area_First_30_Seconds(32,3);Occupancy_Per_Area_First_30_Seconds(33,1),Occupancy_Per_Area_First_30_Seconds(33,2),Occupancy_Per_Area_First_30_Seconds(33,3)};
        xlswrite(Filename,Combined_Occupancy_Data_First_30_Seconds,'First30Seconds','E1');
        xlswrite(Filename,{'Total Duration In Center','Total Path Length In Center','Total Duration In 200s','Total Path Length In 200s','Total Duration in 300s','Total Path Length in 300s';sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)<200,2)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)<200,3)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>200 & Occupancy_Per_Area_First_30_Seconds(:,1)<300,2)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>200 & Occupancy_Per_Area_First_30_Seconds(:,1)<300,3)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>300,2)),sum(Occupancy_Per_Area_First_30_Seconds(Occupancy_Per_Area_First_30_Seconds(:,1)>300,3))},'First30Seconds','I1');
        xlswrite(Filename,Analyzed_Data,'RawData','A1');
        close(Figure1);
        warning('on','all')
    end

end

